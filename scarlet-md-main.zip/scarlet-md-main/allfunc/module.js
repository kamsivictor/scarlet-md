module.exports = {
modul: {
	
	googleTTS: require('google-tts-api'),
	FormData: require('form-data'),
}
}